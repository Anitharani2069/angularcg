import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Product } from './product';
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }

  jsonData='/assets/productBrands.json';

  getProduct():Observable<Product[]>{
    return this.http.get<Product[]>(this.jsonData);
  }
}
