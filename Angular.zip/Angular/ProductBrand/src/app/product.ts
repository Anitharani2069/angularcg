export class Product {

    ProductId:string;
    Category:string;
    MainCategory:string;
    TaxTariffCode:number;
    SupplierName:string;
}