import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product';

@Component({
  selector: 'app-productbrands',
  templateUrl: './productbrands.component.html',
  styleUrls: ['./productbrands.component.css']
})
export class ProductbrandsComponent implements OnInit {

  constructor(private service:ProductService) { }

  productArray:Product[];

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.service.getProduct().subscribe(x=>this.productArray=x);
  }

}
