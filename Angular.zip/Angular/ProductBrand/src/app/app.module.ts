import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpClientModule,HttpClient} from '@angular/common/http'
import {FormsModule} from '@angular/forms'
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ProductbrandsComponent } from './productbrands/productbrands.component';
import { AboutComponent } from './about/about.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';

const routes:Routes=[
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'about',component:AboutComponent},
  {path:'productbrand',component:ProductbrandsComponent},
  {path:'home',component:HomeComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    ProductbrandsComponent,
    AboutComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes),

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
