import { Directive,ElementRef,Renderer,HostListener } from '@angular/core';

@Directive({
  selector: '[appChangeText]'
})
export class ChangeTextDirective {

  constructor(private e1:ElementRef) {
    e1.nativeElement.innerText="This is Ng Style";
   }
   @HostListener("mouseover") onHover(){
      alert("hover");
   }
}
