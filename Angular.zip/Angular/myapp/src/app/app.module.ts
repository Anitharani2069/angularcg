import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { DirectivesComponent } from './directives/directives.component';

import { ChangeTextDirective } from './change-text.directive';
import { CustompipePipe } from './custompipe.pipe';
import { StudentComponent } from './student/student.component';
import { StudentService } from './student.service';
import { CustomerComponent } from './customer/customer.component';
import { RegisterComponent } from './register/register.component';

@NgModule({
  declarations: [
    AppComponent,UserComponent, DirectivesComponent,  ChangeTextDirective, CustompipePipe, StudentComponent, CustomerComponent, RegisterComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [RegisterComponent]
})
export class AppModule { }
