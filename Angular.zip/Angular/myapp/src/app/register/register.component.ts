import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 
@Component({
 selector: 'app-register',
 templateUrl: './register.component.html',
 styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 uname:string;
 pwd:string;
 registerForm: FormGroup;
 submitted = false;
 constructor(private formBuilder: FormBuilder) { }
 
 ngOnInit() {
 this.registerForm = this.formBuilder.group({
 
 uname: ['', [ Validators.required, Validators.minLength(4)]],
 pwd: ['', [ Validators.required, Validators.pattern('[A-Z]{5}')]]
 });
 
 }
 get f() {
return this.registerForm.controls;
 }
 
 onSubmit(data) {
 this.submitted = true;
 
 if(this.registerForm.invalid) {
return;
 }
 alert('Formm Submitted Successfully');
 this.uname=data.uname;
 this.pwd=data.pwd;
 }
 }