import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
isValid="false";
name:string="hello"
jsonObj={
  eid:"101",ename:"anitha",es:"5000"
}
cities=["pune","hyderabad","mumbai","chennai","banglore"];
choice:number=4;

  constructor() { }
  ngOnInit() {
  }
}
