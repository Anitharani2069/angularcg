import { Component, Input, Injectable } from '@angular/core';
@Injectable({
  providedIn:'root'
})

@Component({
  selector: 's1',
  templateUrl: './app.component.html',
  styles: ['h1{color:green}']
})
export class AppComponent {
  
  parentValue:string ="Hi I am Parent";
  title:string = 'Capgemini';
  id:number=101;
  name:string="anithabhairi";
  isvalid:boolean=true;
  value:any='any value';
  image:string="assets/download.jpg";
  city:string="Chennai";
  sayHello(){
   alert("Hello Friends...");
  }
  getData(value){
    alert(value);
  }
}
