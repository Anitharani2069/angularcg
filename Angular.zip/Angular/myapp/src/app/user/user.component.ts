import { Component, OnInit, Input,EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
uname:string = "anitha";
@Input()
acceptData:string;
@Output()
obj:EventEmitter<string> = new EventEmitter<string>();
childData:string="Hi I am Child";
sendData(){
  this.obj.emit(this.childData);
}
  constructor() { } 
  ngOnInit() { 
  }
}
