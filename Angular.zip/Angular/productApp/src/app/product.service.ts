import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from '../../node_modules/rxjs';
import { Product } from './product/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

    url = '/assets/data/db.json';

   getAllProducts(): Observable<Product[]> {

  return this.http.get<Product[]>(this.url);

   }



}
